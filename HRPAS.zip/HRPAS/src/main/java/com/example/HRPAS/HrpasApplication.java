package com.example.HRPAS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HrpasApplication {

	public static void main(String[] args) {
		SpringApplication.run(HrpasApplication.class, args);
	}

}
