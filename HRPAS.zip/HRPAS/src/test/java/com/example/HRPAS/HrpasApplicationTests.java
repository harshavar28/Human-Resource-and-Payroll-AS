package com.example.HRPAS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HrpasApplicationTests {

	@Test
	void contextLoads() {
	}

}
